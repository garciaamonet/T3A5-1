
package t3a05;

import java.util.Scanner;

public class T3A05 {

    
    public static void main(String[] args) {
          menu();
    }
    
    public static void menu(){
        Cuenta cuenta = new Cuenta();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bienvenido a banco x "
                + "1. Consultar saldo/n "
                + "2. Consultar estado de cuenta/n  "
                + "3. Retirrar efectivo/n  "
                + "4. Otras opciones/n  "
                + "5. Salir  "
                + "/N/N Elija una operaci�n ");
        
        int operacion = scanner.nextInt();
        switch (operacion){
            case 1:
                cuenta.consultarSaldo();
                break;
            case 2:
                cuenta.estadoDeCuenta();
                break;
            case 3:
                cuenta.retirarEfectivo();
                break;
            case 4:
                System.out.println("1.Seguros/n"
                        +"2. Creditos/n/n"
                        + "Elija uno: ");
                int opcion = scanner.nextInt();
              
                switch (opcion) {
                    case 1:
                        cuenta.seguro();
                        break;
                    case 2:
                        cuenta.creditos();
                        break;
                    default:
                        System.err.println("Elija una opcion v�lida ");
                        break;
                }
                
            break;
            }
    }
    
}
