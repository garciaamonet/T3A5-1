
package t3a05;

public class Cuenta {
    
private String numeroCuenta;
    private int pin;
    private float saldo;

    public Cuenta() {
    }

    public Cuenta(String numeroCuenta, int pin, float saldo) {
        this.numeroCuenta = numeroCuenta;
        this.pin = pin;
        this.saldo = saldo;
    }

    public void consultarSaldo() {
        System.out.println("Tienes un saldo: " + getSaldo());
    }

    public void estadoDeCuenta() {
        System.out.println("Estado de cuenta/n/n"
                + "Cuenta:  " + getNumeroCuenta()
                + "/NSaldo:  " + getSaldo()
                + "/N/NUltimos movimientos: ");

    }

    public void retirarEfectivo() {
        if (getSaldo() > 0) {
            System.out.println("�Cu�nto desea retirar? ");
        } else {
            System.out.println("No puedo ayudarte con esta operaci�n"
                    + "/nFondos Insuficientes");
        }
    }

    public void seguro() {
        System.out.println("SEGUROS"
                + "/n1.Seguro de auto"
                + "/n2.Seguro de vida"
                + "/n3.Seguro m�dico"
                + "/n4.Seguro de vivienda");

    }

    public void creditos() {
        System.out.println("CREDITOS"
                + "/n1.HIPOTECARIO"
                + "/n2. Crediauto"
                + "n/3. Familiar"
                + "/n4. Personal");

    }

    public void salir() {
        System.out.println("Gracias por ocupar nuestro serivicio");

    }

    @Override
    public String toString() {
        String mensaje = "Numero de cuenta: " + numeroCuenta;
        return mensaje;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

}
